# AI-Driven Public Health Chatbot (Free - Rasa + FastAPI + Webchat)

This ZIP contains a complete **free-of-cost** project scaffold that runs locally:
- Rasa chatbot (NLU + stories + domain)
- FastAPI actions server (vaccine schedule + mock outbreak lookup)
- Simple Webchat widget (index.html)
- Optional: docker-compose (to run components with Docker)
- Instructions to run locally (no paid services)

## Quick steps (minimum, using local Python)
1. Install Python 3.9+ and pip.
2. (Recommended) Create virtualenv:
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux/Mac
   venv\Scripts\activate    # Windows
   ```
3. Install dependencies:
   ```bash
   pip install rasa==3.7.4 fastapi uvicorn requests
   ```
   > If `rasa[full]` is desired (extra libs), install `pip install rasa[full]` but it's larger.

4. Train the model:
   ```bash
   rasa train
   ```

5. Start action server (custom actions + FastAPI mock API):
   ```bash
   # from actions/ directory
   uvicorn actions.main:app --reload --port 5055
   ```
   The actions server includes two roles:
   - Rasa custom actions endpoints (action implementations)
   - Mock health API endpoints (vaccine schedule, outbreak lookup)

6. Run Rasa:
   ```bash
   rasa run -m models --enable-api --cors "*" --debug
   ```

7. Open the Webchat:
   - Open `webchat/index.html` in your browser. It talks to Rasa's REST channel at http://localhost:5005/webhooks/rest/webhook
   - Alternatively test in terminal: `rasa shell`

## Telegram (optional, free)
You can create a Telegram bot and configure a simple connector to forward messages to Rasa REST webhook. See docs/telegram_instructions.md in this ZIP.

## Files included
- rasa/ (domain.yml, config.yml, data/nlu.yml, data/stories.yml, responses.yml, endpoints.yml)
- actions/ (main.py -> FastAPI + actions; requirements.txt)
- webchat/ (index.html)
- docker-compose.yml (optional)
- README.md (this file)

---

If you want, I can:
- Expand NLU dataset per language (Hindi, English) with more utterances.
- Provide a Docker-based quickstart that runs everything with `docker-compose up`.
- Record step-by-step video-like screenshots (as images) showing setup.

Download the ZIP below after it's created.
