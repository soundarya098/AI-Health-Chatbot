# Telegram Bot Instructions (Free)

1. Open Telegram and search for @BotFather
2. Create a new bot using /newbot and follow instructions. Save the Bot Token.
3. Use a simple webhook forwarder or create a small script that forwards Telegram updates to Rasa REST webhook:
   - Receive updates from Telegram via `getUpdates` or set a webhook.
   - Extract `chat.id` and message text and POST to Rasa REST webhook:
     POST http://localhost:5005/webhooks/rest/webhook
     body: { "sender": "telegram_<chat_id>", "message": "<text>" }
4. To reply back to the user, read Rasa's response array and send messages via Telegram's sendMessage API:
   POST https://api.telegram.org/bot<YOUR_TOKEN>/sendMessage
   body: { chat_id: <chat_id>, text: <bot_text> }
5. This connector is free — only internet access is required to talk to Telegram servers.

