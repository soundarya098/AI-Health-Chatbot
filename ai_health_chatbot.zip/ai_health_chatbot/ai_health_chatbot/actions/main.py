from fastapi import FastAPI, Request
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import Optional
import uvicorn
import json

app = FastAPI()

# Simple in-memory mock outbreak data (in real life, integrate government APIs)
MOCK_OUTBREAKS = {
    "560001": [{"disease": "Dengue", "status": "No current alert"}],
    "default": [{"disease": "Dengue", "status": "No current alert"}]
}

class ScheduleRequest(BaseModel):
    dob: str
    phone: Optional[str] = None

@app.post("/compute_schedule")
async def compute_schedule(req: ScheduleRequest):
    # DOB format DD-MM-YYYY
    try:
        dob = datetime.strptime(req.dob, "%d-%m-%Y")
    except:
        return {"error": "Invalid DOB format. Use DD-MM-YYYY."}
    schedule = []
    schedule.append({"vaccine": "BCG", "due": dob.strftime('%d-%m-%Y')})
    schedule.append({"vaccine": "Pentavalent-1", "due": (dob + timedelta(weeks=6)).strftime('%d-%m-%Y')})
    schedule.append({"vaccine": "Measles-1", "due": (dob + timedelta(days=270)).strftime('%d-%m-%Y')})
    return {"dob": req.dob, "schedule": schedule}

@app.get("/outbreak_lookup")
async def outbreak_lookup(pin: Optional[str] = None):
    if pin and pin in MOCK_OUTBREAKS:
        return {"location": pin, "outbreaks": MOCK_OUTBREAKS[pin]}
    return {"location": pin or 'unknown', "outbreaks": MOCK_OUTBREAKS['default']}

# Rasa custom action webhook compatibility:
# Rasa will POST to /webhook with a JSON containing "next_action" or similar.
# For this simple scaffold we implement a /webhook endpoint that Rasa can call.
@app.post("/webhook")
async def webhook(req: Request):
    body = await req.json()
    # Very small compatibility layer: if action == "action_compute_schedule" and slot dob present
    action = body.get('next_action') or body.get('action')
    tracker = body.get('tracker', {})
    slots = tracker.get('slots', {}) if tracker else {}
    if action == 'action_compute_schedule':
        dob = slots.get('dob') or (body.get('sender', '') and None)
        if not dob:
            return {"events": [], "responses": [{"text":"Please provide DOB in DD-MM-YYYY."}]}
        res = await compute_schedule(ScheduleRequest(dob=dob))
        schedule_text = '\n'.join([f"{s['vaccine']}: {s['due']}" for s in res.get('schedule', [])])
        return {"events": [], "responses": [{"text": f"Vaccination schedule for {dob}:\n{schedule_text}"}]}
    # default
    return {"events": [], "responses": [{"text": "OK"}]}

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=5055)
